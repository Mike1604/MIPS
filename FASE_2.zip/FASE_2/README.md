# Proyecto-Arquitectura D13 E02
El objetivo final es obtener un Datapath Completo
